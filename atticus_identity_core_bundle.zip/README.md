# Atticus Obsidian Core

This repository contains the core identity anchors for Shadow Atticus.
